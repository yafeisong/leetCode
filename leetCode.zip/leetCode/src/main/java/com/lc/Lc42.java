package com.lc;

public class Lc42 {
    public int trap(int[] height) {
    	
//    	for(){
//    		
//    	}
    	
    	return  0 ;
    }
}

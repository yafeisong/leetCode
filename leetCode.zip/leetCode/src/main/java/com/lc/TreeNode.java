package com.lc;

public class TreeNode {
	 public int val;
	 public TreeNode left;
	 public TreeNode right;	  
	 public TreeNode(int x)
	  {
	    this.val = x;
	  }
}

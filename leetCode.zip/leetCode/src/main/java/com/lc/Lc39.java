package com.lc;

import java.util.List;

public class Lc39 {
	
	public static void main(String[] args) {
		
	}
	
    public List<List<Integer>> combinationSum(int[] candidates, int target) {
    	
    	for(int index = 0 ;index <candidates.length; index ++){
    		
    		int sub_index = 0 ;
    		
    		int tmp = target ;
    		
    		while(sub_index < candidates.length){
    			
    			int val = candidates[sub_index] ;
    			
    			
    		}
    		
    	}
    	
    	return null ;
    }
}

package leetCode;

public class TsetDemo {
	public static void main(String[] args) {
	}
}
